package com.example.myapplication01

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.DatePicker
import android.widget.TimePicker
import java.util.*

class Main2Activity : AppCompatActivity(),DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    var day = 0
    var month = 0
    var year = 0
    var hour = 0
    var minute = 0

    var savedDay = 0
    var savedMonth = 0
    var savedYear = 0
    var savedHour = 0
    var savedMinutes = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        pickDate()
    }
    private fun getDataTimeCalender(){
        val cal = Calendar.getInstance()
        day =cal.get(Calendar.DAY_OF_MONTH)
        month =cal.get(Calendar.MONTH)
        year =cal.get(Calendar.YEAR)
        hour =cal.get(Calendar.HOUR)
        minute =cal.get(Calendar.MINUTE)
    }
    private fun pickDate(){
        btn_timePicker.setOnClickListener{
            getDataTimeCalender()

            DatePickerDialog(this,this,year,month,day).show()
        }
    }
    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayofMonth: Int) {
     savedDay = dayofMonth
     savedMonth = month
     savedYear = year

        getDataTimeCalender()
        TimePickerDialog(this,this,hour,minute,true).show()
    }

    override fun onTimeSet(p0: TimePicker?, hourofDay: Int, minute: Int) {
     savedHour = hourofDay
     savedMinutes = minute
        tv_textTime.text = "$savedDay~$savedMonth~$savedYear\n Hour: $savedHour Minutes: $savedMinutes"
    }
}

